how to compile:

1. unzip hull.zip
2. replace stormacs.h by the provided one
3. make

for more info see:
http://stackoverflow.com/questions/6833243/how-can-i-find-the-alpha-shape-concave-hull-of-a-2d-point-cloud

and

http://weblog.bocoup.com/compiling-clarksons-hull-in-os-x/

"As a service to all of those architects and designers out there who’d
rather not learn C, here’s the fix. Replace the “stormacs.h” file with
this guy: stormacs.h and you should be good to go."

mma, jan 2013


